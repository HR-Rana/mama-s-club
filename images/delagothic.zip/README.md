<img src = documantation/img/img_01.jpg />

<h2>このフォントについて</h2>
太いゴシック体をテーマに製作したフォントです。 文字の枠を横長に設定しておりどっしりとした安定感あります。<br />
文字数も豊富に収録しているので様々な場面でお使いいただけます。<br />

<h2>収録文字</h2>
・半角英数、約物、（Google Latin Core)<br />
・ひらがな カタカナ 全角英数 全角記号 縦書き用文字<br />
・漢字 jis第三水準まで<br />

<h2>SIL Open Font License Version 1.1ライセンスについて</h2>

・趣味 商用にかかわらず無償で使用できます。<br />
・ゲームやアプリなどへの組み込みも可能です。<br />
・このフォントをもとに派生フォントやwebフォントを作ることもできます。<br />
　ただし、配布する場合はSIL Open Font Licenseに基づいてリリースする必要があります。<br />

・SILライセンスについて詳しくはライセンス原文日本語サイト<br />
　（https://ja.osdn.net/projects/opensource/wiki/SIL_Open_Font_License_1.1）<br />
　または同梱の「OFL.txt」（英語）をご確認ください。<br />

<h2>できないこと</h2>
・「SIL Open Font License Version 1.1」以外のライセンスで再配布すること。<br />
・フォントファイル自体を単体で販売すること。<br />

<h2>更新履歴</h2>
・2020.03.28 リリース
